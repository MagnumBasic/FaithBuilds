3/29/25 OST Fate added.   
4/5/25 World drawler added.   
4/10/25 Build system added.   
4/10/25 Terrain generation added.   
4/16/25 Block collision added.    
4/16/20 Steping added.    
4/16/25 Block placing added.    
4/20/25 Custom cursor added.    
4/21/25 Water added.    
4/21/25 Build UI changed.   
4/21/25 Inventory hotbar added.   
4/23/25 Light added.    
4/23/25 Controller supoort added.   
4/26/25 Debuged movement.   

V1.4    
4/28/25 Main menu added.    
4/28/25 Loading menu changed.   
4/30/25 Pause menu added.   
4/30/25 Inventory added.    
4/30/25 Movement system changed.    
4/30/25 Grass display system changed.   
4/30/25 Bricks added.   
4/31/25 Sand added.   
5/1/25 Sand in terrain generation added.    

V1.5   
5/5/25 Adjusted terrain generation to prevent in-water spawning.    
5/5/25 Caves added.   
5/5/25 Debugged block stepping while in water.    
5/5/25 Inventory System added.    
5/5/25 Trees added.   
5/5/25 Added ore generation (chalcopyrite and ferromagnesian).    
5/5/25 Torches added.   

V1.6    
5/6/25 Crafting added.    
5/6/25 Added time.    
5/6/25 Rain added.    
5/6/25 Added glass.   
5/9/25 Slimes added.    
5/12/25 World border collision fixed.   
5/12/25 Grimstone added.    

V1.7    
5/12/25 Fixed glass.    
5/12/25 Inventory UI made better.   
5/12/25 Added wood.   
5/12/25 Added sticks.   
5/12/25 Change torch crafting recipe.   
5/12/25 Mob light level effect added.   
5/12/25 Health added.   
5/12/25 Ladders added.    
5/12/25 Added cobblestone & cobblestone wall(s).    
5/13/25 Changed cave generation.    
5/13/25 Water debuged.    
5/13/25 World loading screen fixed.   
5/13/25 Ost Waltz added.    
5/13/25 Light bug fixed.    
5/13/25 Changed slime spawn rate.   
5/13/25 Pause Menu fixed.   
3/13/25 Max scroll distance added.    

V1.8    
5/15/25 New loading scene added.    
5/16/25 Saplings added.   
5/16/25 Sand debuged.   
5/16/25 Natural world update added.    
5/16/25 Added lava.   
5/16/25 Added obsidian.   
5/16/25 Added sulfate.    
5/16/25 Added nulltrite.    
5/16/25 Hell added.   
5/16/25 Alchemy table added.    
5/16/25 Fixed inventory.   
5/16/25 Changed crafting.   
5/16/25 Changed internal crafting system.   
5/16/15 Slime spawn rate fixed.   
5/16/25 Debuged water.    

V1.9    
5/16/25 Wood sword added.   
5/16/25 Cain added.   
5/17/25 Loading bar function updated.   
5/17/25 Added sword damage.   
5/17/25 Added death.    
5/17/25 Added respawning.   
5/18/25 Added green slime gel.    
5/18/25 Essence of envy added.   
5/18/25 Cain boss fight added.    
5/16/25 Inventory item drag added.    

V1.9.1      
5/18/25 Fixed sword attack distance.    
5/18/25 Fixed mob lot.    

V1.10 beta   
5/18/25 Created new crafting system.    
5/18/25 Fixed slime spawn rates.    
5/19/25 Added world save/load system.   

V1.10   
5/19/25 Travesty OST added for Cain boss fight.   
5/19/25 Fixed block placement for mouse & keyboard.   
5/19/25 Fixed loading save world music bug.   
5/19/25 Changed Cain boss health.   
5/19/25 Added stone, iron, copper, and iron swords + sword of severance.    
5/19/25 Added furnace.    
5/19/25 Slime block added.    
5/19/25 Added gold.   
5/19/25 Added bottle, bottle of honey, and wax, bread.   
5/19/25 Added farming.    

V1.11   
5/21/25 Changed crafting ui.    
5/21/25 Fixed Cain spawning.    
5/21/25 Changed torch crafting.   
5/21/25 Added mob despawning.   
5/21/25 Required amount for craftin bug fixed.    
5/21/25 Added item name in inventory.   
5/21/25 Added world border for camera.    
5/21/25 Added anvil.    
5/21/25 Changed mob drop rates.   
5/21/25 Fixed inventory item use will crafting bug.   
5/21/25 Fixed block select bug.   
5/21/25 Added pickaxes.   
5/21/25 Fixed Cain lighting bug.    
5/21/25 Fixed honey gathering bug.    
5/21/25 Added was wings.    

V1.11.1   
5/21/25 Fixed holding item display mob.   
5/21/25 Cain display bug fixed.   
5/21/25 Item holding siplay fixed.    
5/21/25 Fixed copper to iron leveling.    
5/21/25 Fixed boss display health.    

V1.12   
5/24/25 Fixed world display problem.    
5/24/25 Fixed lighting bugs.    
5/24/25 Added aquaphors.    
5/24/25 Added underground rooms.    
5/24/25 Added weeping angels.   
5/24/25 Added ten commandments scroll.    
5/24/25 Debuged slimes.   
5/24/25 Added chest.    
5/24/25 Added mob health bar.   

V1.13   
5/25/25 Fixed crafting required item amount bug.    
5/25/25 Added titanium, plus tool varients.   
5/25/25 Added copper, nulltrite, and titanium anvils + titanium tools.   
5/26/25 Heart crystals added.   
5/26/25 Moved mob obj to world obj.   
5/26/25 Added exit button to main menu and play menu.   
5/26/25 Made new icon.    

V1.14   
5/27/25 Created new mob lighting system.    
5/27/25 Added fire balls.   
5/27/25 Added magic.    
5/27/25 Armor added.    
5/27/25 Added arrows.   
5/27/25 Moses boss added.   

V1.14.1   
5/28/25 Added painting mirage.    
5/28/25 Changed background sprites.   

V1.15   
5/28/25 Fixed controller UI.    
5/28/25 Fixed world save loading menu.    
5/28/25 Fixed zoomed mob pixelation.    
5/28/25 Fixed wall visability.    
5/28/25 Added world background.   
5/28/25 Made new world display system.    

V1.16
5/31/25 Fixed lighting system.    
5/31/25 Fixed crafting attack bug.    
5/31/25 Fixed slime and weeping angel spawn rates.    
5/31/25 Edited the weeping angel sprite.    
5/31/25 Fixed bows.   
5/31/25 Fixed armor hair bug.   
5/31/25 Added chest system.   
5/31/25 Debuged water.    
5/31/25 Fixed weat.   

V1.17   
6/1/25 Fixed item drag while crafting.    
6/1/25 Changed water light updateing.   
6/1/25 Work bench added.    
6/1/25 Added elevator.    
6/1/25 Fixed weeping angel health bar display.    
6/2/25 Added OST deluge.    
6/2/25 Added altimeter.   

V1.18   
6/5/25 Fixed rooms.   
6/5/25 Added wood chair, and wood table.    
6/6/25 Added wood door, patterned wood, woood numbers, clay, and clay pot.   
6/6/25 Added player build collider.   

V1.19   
6/7/25 Fixed mine tiers.    
6/7/25 Changed crafting for elevator shaft, and bricks.   
6/7/25 Fixed inventory UI bugs.   
6/7/25 Added hammer, gunpowder, recall stone, rescind stone, wood pulp, papper, and bed.    
6/7/25 Changed sprite for grimstone wall.   
6/7/25 Added arrow crafting recipe.   
6/7/25 Added fall damage.   
6/7/25 Fixed speed bug while cliping water/laadders.    
6/7/25 Added more world backgrounds.    
6/7/25 Changed terrain generation.    
6/7/25 Added drowning.    
6/7/25 added lava damage.   
6/7/25 added chest generation.    
6/8/25 added wizard hat, and thunder_shoes.   

V1.19.1   
6/8/25 Changed chest generation rate.   
6/8/25 Fixed ore and cave generation.    
6/8/25 Fixed underground depth.   
6/8/25 Changed weeping angel spawn mechanics.   

V1.20   
6/9/25 Fixed health bug.    
6/9/25 Created max amount of HP.    
6/9/25 Added divider for chest inventory.   
6/9/25 Changed the sprite for clay wall.    
6/11/25 Fixed bow of severance.   
6/11/25 Fixed audio bugs.   
6/11/25 Slimes now spawn on ground.   
6/11/25 Changed the color of copper.    
6/11/25 Added copper pipe.    
6/12/25 Added copper boiler, iron pipe, iron boiler, musket, and musket ball.    

V1.21   
6/12/25 Fixed musket item display size.   
6/12/25 Added time cycle.   
6/13/25 Added cotton, cotton seeds, string, and yarn (1 block, 4 items).   
6/13/25 Changed crafting recipe for wood bow, and bed.    
6/13/25 Changed bee hive mechanics.   
6/13/25 Changed the color of fire.    
6/14/25 Placement bug fixed.    
6/14/25 Changed functionality of hoe.   
6/14/25 Hammer functionality fixed.   
6/14/25 Changed functionality of weat (1 block, 1 item).    
6/14/25 Chyanged craafting recipie for bread.   
6/14/25 Changed sprite for nulltrite ore, nulltrite ingot, leaves, sapling, and gold ore.    
6/15/25 Added accessory slots in inventory.   
6/15/25 Changed the sprite for wax.   
6/15/25 Added mechanic goggles (1 item).   
6/15/25 Added mine speed.   
6/15/25 Added dirt sound.   
6/25/35 Added king debuchadnezzar boss (1 block, 3 items).   

    note: world display does not work on mobile.
    note: cameraData obj is used to find screen ratio.
    
    |To do|
    add keybind menu.
    
    add rail roads + minecart.
    add wips.
    
    create weather system.
    
    add fishing.
    add boats.
    
    add flowers.
    add dye.
    add canvas blocks.
    
    add death screen.
    
    add achievements.
    
    add fire.
    
    |Debug|
    
    |Quality|
    add sounds to game.
    make items in inventory dragable.
    fix name display bug for armor in inventory.
    
    |Internal|
    
    
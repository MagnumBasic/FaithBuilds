3/21/25 Alpha added.
3/21/25 HP degeneration added.
3/26/25 Blood Domain added.
3/21/25 Death screen added.
3/18/25 Index var function added.
3/21/25 Moblie support added.
3/21/25 Respawn mechanic added.
3/24/25 Projectiles added.
3/24/25 Beta added.
3/26/25 Gamma added.
3/26/25 Wave system added.
3/26/25 Mob speed changed.
3/26/25 Delta added.

    add shop, uses player HP as curency (hints the description and why the Blood Domain exsists) // Upgrades domains and abilitys.
     
    add Epsilon mob, uses Necromancy Domain to convert mobs that die withen its domain into Zeta mobs.
     
    add Mana Stone Structures and power system.
     
    add mob direction pointer.
3/21/25 Alpha mob moves 1 m/s towards the playerId mob and spawns every 1/s), follows only one player mob to avoid moveToward() breaking.

3/21/25 Mob HP goes down by -100/s
  
3/26/25 Blood Domain: size = sqrt(HP/PI))*2, steals HP from other mobs depending on there Size.

3/21/25 Death screen acurs when player's HP is <= 0.

3/18/25 Mobs contain varibles (var, data) instead of regular data (data), indeVar returns the var id withen a mob, indeItemVar returns the var id within its inputed field, indexMob returns the mobs id that has a "Name" var with the matching input.

3/21/25 Moblie support added.

3/21/25 Respawn mechanic added.

3/24/25 Projectiles added

3/24/25 Beta, a yellow square that fires a yellow projectile at you every 5/s, Beta does not have Blood Domain, spawns every 35/s.

3/26/25 Gamma added, produces Shield Domain that damages projectiles in exspence of MP which depics the size of the Shield Domain.

    add shop, uses player HP as curency (hints the description and why the Blood Domain exsists) // Upgrades domains and abilitys.
     
    add Delta mob, uses lasers to deal damage.
     
    add Epsilon mob, uses Necromancy Domain to convert mobs that die withen its domain into Zeta mobs.
     
    replace spawning system with wave system that uses waves instead of spawning.
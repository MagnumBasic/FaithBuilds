3/29/25 OST Fate added.   
4/5/25 World drawler added.   
4/10/25 Build system added.   
4/10/25 Terrain generation added.   
4/16/25 Block collision added.    
4/16/20 Steping added.    
4/16/25 Block placing added.    
4/20/25 Custom cursor added.    
4/21/25 Water added.    
4/21/25 Build UI changed.   
4/21/25 Inventory hotbar added.   
4/23/25 Light added.    
4/23/25 Controller supoort added.   
4/26/25 Debuged movement.   

V1.4    
4/28/25 Main menu added.    
4/28/25 Loading menu changed.   
4/30/25 Pause menu added.   
4/30/25 Inventory added.    
4/30/25 Movement system changed.    
4/30/25 Grass display system changed.   
4/30/25 Bricks added.   
4/31/25 Sand added.   
5/1/25 Sand in terrain generation added.    

V1.5   
5/5/25 Adjusted terrain generation to prevent in water spawning.    
5/5/25 Caves added.   
5/5/25 Debuged block steping while in water.    
5/5/25 Inventory System added.    
5/5/25 Trees added.   
5/5/25 Added ore generation (chalcopyrite and ferromagnesian).    
5/5/25 Torches added.   



    add command line for testing.
    
    note: world display does not work on mobile.
    
    add keybind menu.
    
    add partial world display system.
    
    add crafting system/menu.
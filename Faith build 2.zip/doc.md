3/21/25 Alpha mob moves 1 m/s towards the playerId mob and spawns every 1/s), follows only one player mob to avoid moveToward() breaking.

3/21/25 Mob HP goes down by -100/s
  
3/21/25 Blood Domain: size = sqrt(Availible HP/PI))*2, steals HP from other mobs depending on there Size.

3/21/25 Death screen acurs when player's HP is <= 0.

3/18/25 Mobs contain varibles (var, data) instead of regular data (data), indeVar returns the var id withen a mob, indeItemVar returns the var id within its inputed field, indexMob returns the mobs id that has a "Name" var with the matching input.

3/21/25 Moblie support added.

    add shop, uses player HP as curency (hints the description and why the Blood Domain exsists) // Upgrades domains and abilitys.
     
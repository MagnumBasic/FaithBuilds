Alpha mob moves 1 m/s towards the playerId mob and spawns every 5/s withen a 500m distance of the player mob(s), follows only one player mob to avoid moveToward() breaking.

Mob HP goes down by -1/s
Starting HP:
  
  Player, 50
  
  Alpha, 50
  
Blood Domain: size = mob HP + mob size, steals HP from other mobs depending on there HP steal rate.

Death screen acurs when player's HP is <= 0.

3/18/2025 Mobs contain varibles (var, data) instead of regular data (data), indeVar returns the var id withen a mob, indeItemVar returns the var id within its inputed field, indexMob returns the mobs id that has a "Name" var with the matching input.

        
    implament mobile support
      
    add shop, uses player HP as curency (hints the description and why the Player steals the health of enemys) // Upgrades domains and abilitys.
3/21/25 Death screen added.   
3/21/25 Index var function added.   
3/21/25 Moblie support added.   
3/21/25 Respawn mechanic added.   
3/29/25 OST Fate added.   
4/5/25 World drawler added.   
4/10/25 Build system added.   
4/10/25 Terrain generation added.   
4/16/25 Block collision added.    
4/16/20 Steping added.    
4/16/25 Mobile support updated.   
4/16/25 Block placing added.    
4/20/25 Custom cursor added.    
4/21/25 Water added.    
4/21/25 Build UI changed.   
4/21/25 Inventory added.   
4/23/25 Light added.    
4/23/25 Controller supoort added.   



    add command line for testing.
    
    note: world display does not work on mobile.
    
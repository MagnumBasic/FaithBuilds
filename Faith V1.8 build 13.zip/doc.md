3/29/25 OST Fate added.   
4/5/25 World drawler added.   
4/10/25 Build system added.   
4/10/25 Terrain generation added.   
4/16/25 Block collision added.    
4/16/20 Steping added.    
4/16/25 Block placing added.    
4/20/25 Custom cursor added.    
4/21/25 Water added.    
4/21/25 Build UI changed.   
4/21/25 Inventory hotbar added.   
4/23/25 Light added.    
4/23/25 Controller supoort added.   
4/26/25 Debuged movement.   

V1.4    
4/28/25 Main menu added.    
4/28/25 Loading menu changed.   
4/30/25 Pause menu added.   
4/30/25 Inventory added.    
4/30/25 Movement system changed.    
4/30/25 Grass display system changed.   
4/30/25 Bricks added.   
4/31/25 Sand added.   
5/1/25 Sand in terrain generation added.    

V1.5   
5/5/25 Adjusted terrain generation to prevent in-water spawning.    
5/5/25 Caves added.   
5/5/25 Debugged block stepping while in water.    
5/5/25 Inventory System added.    
5/5/25 Trees added.   
5/5/25 Added ore generation (chalcopyrite and ferromagnesian).    
5/5/25 Torches added.   

V1.6
5/6/25 Crafting added.    
5/6/25 Added time.    
5/6/25 Rain added.    
5/6/25 Added glass.   
5/9/25 Slimes added.    
5/12/25 World border collision fixed.   
5/12/25 Grimstone added.    

V1.7
5/12/25 Fixed glass.    
5/12/25 Inventory UI made better.   
5/12/25 Added wood.   
5/12/25 Added sticks.   
5/12/25 Change torch crafting recipe.   
5/12/25 Mob light level effect added.   
5/12/25 Health added.   
5/12/25 Ladders added.    
5/12/25 Added cobblestone & cobblestone wall(s).    
5/13/25 Changed cave generation.    
5/13/25 Water debuged.    
5/13/25 World loading screen fixed.   
5/13/25 Ost Waltz added.    
5/13/25 Light bug fixed.    
5/13/25 Changed slime spawn rate.   
5/13/25 Pause Menu fixed.   
3/13/25 Max scroll distance added.    

V1.8
5/15/25 New loading scene added.    
5/16/25 Saplings added.   
5/16/25 Sand debuged.   
5/16/25 Natural worldupdate added.    
5/16/25 Added lava.   
5/16/25 Added obsidian.   
5/16/25 Added sulfate.    
5/16/25 Added nulltrite.    
5/16/25 Hell added.   
5/16/25 Alchemy table added.    
5/16/25 Fixed inventory.   
5/16/25 Changed crafting.   
5/16/25 Changed internal crafting system.   
5/16/15 Slime spawn rate fixed.   
5/16/25 Debuged water.    


    note: world display does not work on mobile.
    
    |To do|
    add keybind menu.
    
    make better inventory ui.
      -add tools.
        -add death/respawn system.
        -add air breathing stat, like minecraft bubbles.
      -redo crafting.
    
    add lava damage [addhealth]
    
    |Debug|
    fix world border collision for slimes.
    
    |Quality|
    make flowing water push mobs.
    add rain sounds.
    make rain despawn when inside block.
    add world background.
    
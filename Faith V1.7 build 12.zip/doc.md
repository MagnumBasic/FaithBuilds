3/29/25 OST Fate added.   
4/5/25 World drawler added.   
4/10/25 Build system added.   
4/10/25 Terrain generation added.   
4/16/25 Block collision added.    
4/16/20 Steping added.    
4/16/25 Block placing added.    
4/20/25 Custom cursor added.    
4/21/25 Water added.    
4/21/25 Build UI changed.   
4/21/25 Inventory hotbar added.   
4/23/25 Light added.    
4/23/25 Controller supoort added.   
4/26/25 Debuged movement.   

V1.4    
4/28/25 Main menu added.    
4/28/25 Loading menu changed.   
4/30/25 Pause menu added.   
4/30/25 Inventory added.    
4/30/25 Movement system changed.    
4/30/25 Grass display system changed.   
4/30/25 Bricks added.   
4/31/25 Sand added.   
5/1/25 Sand in terrain generation added.    

V1.5   
5/5/25 Adjusted terrain generation to prevent in-water spawning.    
5/5/25 Caves added.   
5/5/25 Debugged block stepping while in water.    
5/5/25 Inventory System added.    
5/5/25 Trees added.   
5/5/25 Added ore generation (chalcopyrite and ferromagnesian).    
5/5/25 Torches added.   

V1.6
5/6/25 Crafting added.    
5/6/25 Added time.    
5/6/25 Rain added.    
5/6/25 Added glass.   
5/9/25 Slimes added.    
5/12/25 World border collision fixed.   
5/12/25 Grimstone added.    

V1.7
5/12/25 Fixed glass.    
5/12/25 Inventory UI made better.   
5/12/25 Added wood.   
5/12/25 Added sticks.   
5/12/25 Change torch crafting recipe.   
5/12/25 Mob light level effect added.   
5/12/25 Health added.   
5/12/25 Ladders added.    
5/12/25 Added cobblestone & cobblestone wall(s).    
5/13/25 Changed cave generation.    
5/13/25 Water debuged.    
5/13/25 World loading screen fixed.   
5/13/25 Ost Waltz added.    
5/13/25 Light bug fixed.    
5/13/25 Changed slime spawn rate.   
5/13/25 Pause Menu fixed.   
3/13/25 Max scroll distance added.    


    note: world display does not work on mobile.
    
    |To do|
    add keybind menu.
    
    make better inventory ui.
      -add tools.
        -add health.
          -add death/respawn system.
          -add air breathing stat, like minecraft bubbles.
      -redo crafting.
    
    add hell.
      -add lava.
        -does damage [addhealth]
    
    add character creator.
      -16 hair styles.
      -8 eye styles.
      -8 skin colors.
      -gender
    
    |Debug|
    fix world border collision for slimes.
    
    |Quality|
    make flowing water push mobs.
    add rain sounds.
    make rain despawn when inside block.
    